from django.apps import AppConfig


class GmailConfig(AppConfig):
    name = 'gmail'
